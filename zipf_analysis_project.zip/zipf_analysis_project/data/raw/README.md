# data/raw/

Place any **unprocessed** Bengali corpus files here (e.g. raw scraped text,
raw dumps, original source files before cleaning/tokenization).

This directory is not read directly by the analysis pipeline. It exists so
that the preprocessing step (owned by the corpus-collection teammate) has a
clear place to put source material before producing the final processed file
expected at:

```
data/processed/bengali_corpus.txt
```

Nothing in this folder is committed to version control by default (see
`.gitignore`), aside from this README.

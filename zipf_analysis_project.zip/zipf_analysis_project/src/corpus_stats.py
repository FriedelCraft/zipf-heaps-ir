"""
corpus_stats.py

Basic corpus statistics for the Bengali corpus (or any UTF-8 text corpus):

- total token count
- vocabulary size
- type-token ratio
- hapax legomena count / percentage
- frequency distribution summary
- top-K most frequent tokens

Works with raw Unicode text (Bengali or otherwise) via simple whitespace
tokenization. This tokenizer is intentionally simple; if the corpus
teammate applies a specific tokenization scheme upstream, this module
will just count whatever tokens are already separated by whitespace in
the processed file.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from .utils import get_logger

logger = get_logger(__name__)


def read_corpus_tokens(corpus_path: Path, encoding: str = "utf-8") -> list[str]:
    """
    Read a text corpus and split into whitespace-delimited tokens.

    Raises FileNotFoundError if the corpus does not exist (callers should
    catch this and print a friendly message via utils.print_missing_corpus_message).
    """
    corpus_path = Path(corpus_path)
    if not corpus_path.exists():
        raise FileNotFoundError(f"Corpus file not found: {corpus_path}")

    text = corpus_path.read_text(encoding=encoding)
    tokens = text.split()
    return tokens


@dataclass
class CorpusStatistics:
    total_tokens: int
    vocabulary_size: int
    type_token_ratio: float
    hapax_count: int
    hapax_percentage: float
    min_frequency: int
    max_frequency: int
    mean_frequency: float
    median_frequency: float

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(
            [
                {"metric": "total_tokens", "value": self.total_tokens},
                {"metric": "vocabulary_size", "value": self.vocabulary_size},
                {"metric": "type_token_ratio", "value": self.type_token_ratio},
                {"metric": "hapax_count", "value": self.hapax_count},
                {"metric": "hapax_percentage", "value": self.hapax_percentage},
                {"metric": "min_frequency", "value": self.min_frequency},
                {"metric": "max_frequency", "value": self.max_frequency},
                {"metric": "mean_frequency", "value": self.mean_frequency},
                {"metric": "median_frequency", "value": self.median_frequency},
            ]
        )


def compute_frequency_counter(tokens: list[str]) -> Counter:
    """Count token frequencies. Empty-string tokens are dropped defensively."""
    tokens = [t for t in tokens if t]
    return Counter(tokens)


def compute_corpus_statistics(tokens: list[str]) -> CorpusStatistics:
    """Compute summary statistics for a token stream."""
    if len(tokens) == 0:
        logger.warning("Empty token list passed to compute_corpus_statistics().")
        return CorpusStatistics(
            total_tokens=0,
            vocabulary_size=0,
            type_token_ratio=0.0,
            hapax_count=0,
            hapax_percentage=0.0,
            min_frequency=0,
            max_frequency=0,
            mean_frequency=0.0,
            median_frequency=0.0,
        )

    counter = compute_frequency_counter(tokens)
    freqs = pd.Series(list(counter.values()))

    total_tokens = int(sum(counter.values()))
    vocabulary_size = int(len(counter))
    ttr = vocabulary_size / total_tokens if total_tokens > 0 else 0.0
    hapax_count = int((freqs == 1).sum())
    hapax_pct = (hapax_count / vocabulary_size * 100) if vocabulary_size > 0 else 0.0

    return CorpusStatistics(
        total_tokens=total_tokens,
        vocabulary_size=vocabulary_size,
        type_token_ratio=round(ttr, 6),
        hapax_count=hapax_count,
        hapax_percentage=round(hapax_pct, 4),
        min_frequency=int(freqs.min()),
        max_frequency=int(freqs.max()),
        mean_frequency=round(float(freqs.mean()), 4),
        median_frequency=float(freqs.median()),
    )


def top_tokens_dataframe(counter: Counter, top_k: int = 20) -> pd.DataFrame:
    """Return a dataframe of the top-K most frequent tokens with rank."""
    most_common = counter.most_common(top_k)
    df = pd.DataFrame(most_common, columns=["token", "frequency"])
    df.insert(0, "rank", range(1, len(df) + 1))
    return df


def run_corpus_stats(
    corpus_path: Path,
    output_dir: Path,
    encoding: str = "utf-8",
    top_k: int = 20,
) -> dict:
    """
    Full corpus-statistics pipeline: read corpus, compute stats, save CSVs.

    Returns a dict with keys: 'tokens', 'counter', 'statistics' for reuse
    by downstream modules (e.g. zipf_analysis) without re-reading the file.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    tokens = read_corpus_tokens(corpus_path, encoding=encoding)
    counter = compute_frequency_counter(tokens)
    stats = compute_corpus_statistics(tokens)

    stats.to_dataframe().to_csv(output_dir / "corpus_statistics.csv", index=False)
    top_tokens_dataframe(counter, top_k=top_k).to_csv(
        output_dir / "top_tokens.csv", index=False
    )

    logger.info(
        f"Corpus stats: {stats.total_tokens} tokens, "
        f"{stats.vocabulary_size} vocabulary, "
        f"TTR={stats.type_token_ratio}"
    )

    return {"tokens": tokens, "counter": counter, "statistics": stats}
